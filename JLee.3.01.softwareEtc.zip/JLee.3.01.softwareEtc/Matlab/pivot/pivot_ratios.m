% pivot_ratios.m // Jon Lee
% calculate ratios for determing a variable to leave the basis.
% syntax is ratios(j), where we are letting eta_j enter the basis

function pivot_ratios(j)
global xbar_beta Abar_eta m n ratios;
if (j>n-m)
    display('error: j out of range.')
else
ratios = xbar_beta ./ Abar_eta(:,j)
end

display('  To see the ratios in floating point, type: double(ratios),')
display('  or if they are symbolic or you want better control')
display('  of precision, type: vpa(ratios,d)')
display('  to get the same and with d digits of precision')



