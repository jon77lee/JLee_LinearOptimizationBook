% pivot_input2.m // Jon Lee
% data for pivoting example
%
% this is really the same problem as pivot_input.m, but
%  - the rhs is symbolically perturbed, so we can easily do lex pivots.
%
syms t real;
A = [1 2 1 0 0 0; 3 1 0 1 0 0; 3/2 3/2 0 0 1 0; 0 1 0 0 0 1];
A= sym(A);
c = [6 7 -2 0 4 9/2]';
c=sym(c);
b = [7 9 6 33/10]';
b=sym(b);
beta = [1,2,4,6];
[m,n] = size(A);
eta = setdiff(1:n,beta); % lazy eta initialization 
b = b + A(:,beta)*[t t^2 t^3 t^4]'; % lex feasible if beta is feasible