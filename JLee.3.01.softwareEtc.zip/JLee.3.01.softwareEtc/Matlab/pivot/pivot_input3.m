% pivot_input3.m // Jon Lee
% data for pivoting example

syms theta gamma pi;
syms t real;

theta= 2*pi/5;
gamma = cot(theta);

R= [ cos(theta) -sin(theta); sin(theta) cos(theta)];
A1 = [1 0]';
A2 = [0 gamma]';
A = [A1 A2 R*A1 R*A2 R^2*A1 R^2*A2 R^3*A1 R^3*A2 R^4*A1 R^4*A2];
A= sym(A);
c = ( ones(1,10) -  [1 1/gamma]*A )';
c=sym(c);
b = [0 0]';
b=sym(b);
beta = [1,2];
[m,n] = size(A);
eta = setdiff(1:n,beta); % lazy eta initialization 
%
% uncomment next line to lexically perturb the rhs
b = b + A(:,beta)*[t t^2]'; % lex feasible if beta is feasible